"use strict";
(() => {
  // ../../packages/dlp/src/index.ts
  var SECRET_PATTERNS = [
    ["AWS access key", /\b(?:AKIA|ASIA)[0-9A-Z]{16}\b/g],
    ["GitHub token", /\bgh[pousr]_[A-Za-z0-9]{36,}\b/g],
    ["GitHub token", /\bgithub_pat_[A-Za-z0-9_]{60,}\b/g],
    ["Slack token", /\bxox[abposr]-[A-Za-z0-9-]{10,}\b/g],
    ["Anthropic key", /\bsk-ant-[A-Za-z0-9_-]{20,}\b/g],
    ["OpenAI key", /\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{32,}\b/g],
    ["Google API key", /\bAIza[0-9A-Za-z_-]{35}\b/g],
    ["Stripe key", /\b(?:sk|rk)_live_[0-9A-Za-z]{20,}\b/g],
    ["JWT", /\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/g],
    ["Connection string with a password", /\b[a-z][a-z0-9+.-]*:\/\/[^\s:/@]+:[^\s@/]{3,}@[^\s/]+/gi],
    ["Password", /\b(?:password|passwd|pwd|secret|api[_-]?key|access[_-]?token|client[_-]?secret)\s*[:=]\s*["']?[^\s"']{8,}/gi]
  ];
  var PRIVATE_KEY = /-----BEGIN (?:RSA |EC |DSA |OPENSSH |ENCRYPTED |PGP )?PRIVATE KEY(?: BLOCK)?-----/g;
  var CARD = /\b(?:\d[ -]?){12,18}\d\b/g;
  var SSN = /\b(?!000|666|9\d\d)\d{3}-(?!00)\d{2}-(?!0000)\d{4}\b/g;
  var IBAN = /\b[A-Z]{2}\d{2}(?:[ ]?[A-Z0-9]{4}){2,7}(?:[ ]?[A-Z0-9]{1,4})?\b/g;
  var EMAIL = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g;
  function luhn(digits) {
    let sum = 0;
    for (let i = 0; i < digits.length; i++) {
      let d = digits.charCodeAt(digits.length - 1 - i) - 48;
      if (i % 2 === 1) {
        d *= 2;
        if (d > 9) d -= 9;
      }
      sum += d;
    }
    return sum % 10 === 0;
  }
  var CARD_PREFIX = /^(?:4\d{12}(?:\d{3}){0,2}|5[1-5]\d{14}|2(?:2[2-9][1-9]|[3-6]\d\d|7[01]\d|720)\d{12}|3[47]\d{13}|6(?:011|5\d\d)\d{12,15}|35(?:2[89]|[3-8]\d)\d{12,15}|3(?:0[0-5]|[68]\d)\d{11,16}|62\d{14,17})$/;
  function ibanValid(raw) {
    const s = raw.replace(/\s+/g, "").toUpperCase();
    if (s.length < 15 || s.length > 34) return false;
    const moved = s.slice(4) + s.slice(0, 4);
    let rem = 0;
    for (const ch of moved) {
      const v = /\d/.test(ch) ? ch : String(ch.charCodeAt(0) - 55);
      for (const c of v) rem = (rem * 10 + (c.charCodeAt(0) - 48)) % 97;
    }
    return rem === 1;
  }
  function literalValue(match) {
    const v = match.replace(/^[^:=]*[:=]\s*/, "");
    if (/^["']/.test(v)) return true;
    return !/^[A-Za-z_$][\w$]*(?:\.[\w$]+)*(?:\(.*)?[;,)]*$/.test(v) && !v.includes("(") && !v.startsWith("$") && !v.startsWith("{");
  }
  function mask(s, keepEnd = 2) {
    const t = s.trim();
    if (t.length <= 8) return "\u2022\u2022\u2022\u2022";
    return `${t.slice(0, 4)}\u2026${t.slice(-keepEnd)}`;
  }
  var MAX_SCAN = 2e5;
  function scan(text, enabled, custom = []) {
    const t = text.length > MAX_SCAN ? text.slice(0, MAX_SCAN) : text;
    const on = new Set(enabled);
    const out = [];
    const add = (detector, name, matches, hint) => {
      if (matches.length) out.push({ detector, name, count: matches.length, hint: hint(matches[0]) });
    };
    if (on.has("secret")) {
      for (const [name, re] of SECRET_PATTERNS) {
        let m = t.match(re) ?? [];
        if (name === "Password") m = m.filter(literalValue);
        if (m.length) {
          add("secret", name, m, (x) => mask(x));
          break;
        }
      }
    }
    if (on.has("private_key")) add("private_key", "Private key", t.match(PRIVATE_KEY) ?? [], () => "-----BEGIN \u2026 PRIVATE KEY-----");
    if (on.has("credit_card")) {
      const cards = (t.match(CARD) ?? []).filter((m) => {
        const d = m.replace(/[ -]/g, "");
        return CARD_PREFIX.test(d) && luhn(d);
      });
      add("credit_card", "Payment card number", cards, (m) => `\u2022\u2022\u2022\u2022 ${m.replace(/[ -]/g, "").slice(-4)}`);
    }
    if (on.has("us_ssn")) add("us_ssn", "US Social Security number", t.match(SSN) ?? [], (m) => `\u2022\u2022\u2022-\u2022\u2022-${m.slice(-4)}`);
    if (on.has("iban")) add("iban", "IBAN", (t.match(IBAN) ?? []).filter(ibanValid), (m) => `${m.replace(/\s+/g, "").slice(0, 4)}\u2026${m.replace(/\s+/g, "").slice(-2)}`);
    if (on.has("email_list")) {
      const emails = new Set((t.match(EMAIL) ?? []).map((e) => e.toLowerCase()));
      if (emails.size >= 10) out.push({ detector: "email_list", name: "List of email addresses", count: emails.size, hint: `${emails.size} addresses` });
    }
    for (const c of custom) {
      let re;
      try {
        re = new RegExp(c.pattern, "gi");
      } catch {
        continue;
      }
      add(`custom:${c.id}`, c.name, t.match(re) ?? [], (m) => mask(m));
    }
    return out;
  }

  // src/policy.ts
  function appFor(policy2, hostname) {
    const h = hostname.toLowerCase().replace(/\.$/, "");
    return policy2?.apps.find((a) => a.hosts.some((x) => h === x || h.endsWith(`.${x}`))) ?? null;
  }
  var RANK = { off: 0, monitor: 1, warn: 2, block: 3 };
  function check(policy2, text) {
    const enabled = Object.entries(policy2.dlp.detectors).filter(([, a]) => a !== "off").map(([id]) => id);
    const custom = policy2.dlp.custom.filter((c) => c.action !== "off");
    const actionOf = (detector) => detector.startsWith("custom:") ? custom.find((c) => `custom:${c.id}` === detector)?.action ?? "off" : policy2.dlp.detectors[detector] ?? "off";
    const findings = scan(text, enabled, custom).map((f) => ({ ...f, action: actionOf(f.detector) }));
    const action = findings.reduce((a, f) => RANK[f.action] > RANK[a] ? f.action : a, "off");
    return { action, findings };
  }
  function describe(v) {
    const names = [...new Set(v.findings.map((f) => f.name))];
    return names.length <= 2 ? names.join(" and ") : `${names.slice(0, -1).join(", ")} and ${names.at(-1)}`;
  }
  function dlpEvents(v, app2, host2, action, at = /* @__PURE__ */ new Date()) {
    return v.findings.map((f) => ({ at: at.toISOString(), kind: "dlp", action, app: app2, host: host2, detector: f.detector, count: f.count, detail: `${f.name} ${f.hint}`.slice(0, 300) }));
  }

  // src/content.ts
  var policy = null;
  var app = null;
  var host = location.hostname.toLowerCase();
  var send = (msg) => chrome.runtime.sendMessage(msg).catch(() => null);
  var report = (events) => void send({ type: "report", events });
  var now = () => (/* @__PURE__ */ new Date()).toISOString();
  var isEditable = (el) => !!el && (el.isContentEditable || el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement && /^(text|search|url|email|)$/.test(el.type));
  var lastEditable = null;
  var textOf = (el) => !el ? "" : el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement ? el.value : el.innerText;
  function insert(el, text) {
    el.focus();
    if (!document.execCommand("insertText", false, text) && (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement)) {
      el.setRangeText(text, el.selectionStart ?? el.value.length, el.selectionEnd ?? el.value.length, "end");
      el.dispatchEvent(new Event("input", { bubbles: true }));
    }
  }
  var shadow = null;
  function root() {
    if (shadow) return shadow;
    const hostEl = document.createElement("nexus-guard");
    hostEl.style.cssText = "all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none";
    (document.body ?? document.documentElement).appendChild(hostEl);
    shadow = hostEl.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = `
    .toast,.dialog{font:14px/1.45 -apple-system,Segoe UI,Inter,sans-serif;color:#0f1115;pointer-events:auto}
    .toast{position:fixed;bottom:24px;left:50%;transform:translateX(-50%);max-width:520px;background:#0f1115;color:#fff;border-radius:10px;padding:12px 16px;box-shadow:0 8px 30px rgba(0,0,0,.25)}
    .scrim{position:fixed;inset:0;background:rgba(15,17,21,.45);pointer-events:auto;display:flex;align-items:center;justify-content:center}
    .dialog{background:#fff;border-radius:12px;max-width:460px;width:calc(100% - 32px);padding:22px;box-shadow:0 20px 60px rgba(0,0,0,.3)}
    .brand{font-weight:600;font-size:12px;color:#5b606b;margin-bottom:10px}
    h2{font-size:17px;margin:0 0 8px}
    p{margin:0 0 10px;color:#3b3f47}
    .msg{font-size:13px;color:#5b606b}
    .row{display:flex;gap:8px;justify-content:flex-end;margin-top:16px}
    button{font:inherit;border-radius:7px;padding:8px 14px;border:1px solid #d6d8dd;background:#fff;cursor:pointer}
    button.primary{background:#4f46e5;border-color:#4f46e5;color:#fff}
    @media (prefers-color-scheme: dark){.dialog{background:#1a1c22;color:#eceef2}p{color:#c7cad1}.msg{color:#9aa0ab}button{background:#23262e;color:#eceef2;border-color:#3a3e48}}`;
    shadow.appendChild(style);
    return shadow;
  }
  function toast(text) {
    const el = document.createElement("div");
    el.className = "toast";
    el.setAttribute("role", "status");
    el.textContent = text;
    root().appendChild(el);
    setTimeout(() => el.remove(), 6e3);
  }
  function confirmDialog(title, body, proceed) {
    return new Promise((resolve) => {
      const scrim = document.createElement("div");
      scrim.className = "scrim";
      const d = document.createElement("div");
      d.className = "dialog";
      d.setAttribute("role", "alertdialog");
      d.setAttribute("aria-label", title);
      const el = (tag, cls, text) => Object.assign(document.createElement(tag), { className: cls, textContent: text });
      d.append(el("div", "brand", "Votal Nexus \xB7 your organization"), el("h2", "", title), el("p", "", body));
      if (policy?.message) d.append(el("p", "msg", policy.message));
      const row = el("div", "row", "");
      const cancel = el("button", "primary", "Cancel");
      const go = el("button", "", proceed);
      row.append(go, cancel);
      d.append(row);
      scrim.append(d);
      root().appendChild(scrim);
      const done = (v) => {
        scrim.remove();
        resolve(v);
      };
      cancel.onclick = () => done(false);
      go.onclick = () => done(true);
      cancel.focus();
    });
  }
  var stop = (e) => {
    e.preventDefault();
    e.stopImmediatePropagation();
  };
  async function decide(v, what) {
    if (!app) return true;
    const found = describe(v);
    if (v.action === "block") {
      report(dlpEvents(v, app.key, host, "blocked"));
      toast(`Blocked: this looks like ${found}. Your organization doesn't allow it in ${app.name}.`);
      return false;
    }
    if (v.action === "warn") {
      const ok = await confirmDialog(`${what === "paste" ? "Paste" : "Send"} ${found} to ${app.name}?`, `This looks like ${found}. Once it's sent, ${app.name} has it.`, what === "paste" ? "Paste anyway" : "Send anyway");
      report(dlpEvents(v, app.key, host, ok ? "continued" : "warned"));
      return ok;
    }
    if (v.action === "monitor") report(dlpEvents(v, app.key, host, "monitored"));
    return true;
  }
  function onPaste(e) {
    if (!policy || !app || !e.clipboardData) return;
    if (e.clipboardData.files.length) return void onFiles(e, e.clipboardData.files, e.target);
    const text = e.clipboardData.getData("text/plain");
    if (!text) return;
    const v = check(policy, text);
    if (v.action === "off") return;
    if (v.action === "monitor") return void decide(v, "paste");
    stop(e);
    const target = isEditable(e.target) ? e.target : lastEditable;
    void decide(v, "paste").then((ok) => ok && target && insert(target, text));
  }
  var approved = "";
  function onSend(e, el) {
    if (!policy || !app) return;
    const text = textOf(el).trim();
    if (!text || text === approved) return;
    const v = check(policy, text);
    if (v.action === "off") return;
    if (v.action === "monitor") return void decide(v, "send");
    stop(e);
    void decide(v, "send").then((ok) => {
      if (!ok) return;
      approved = text;
      el?.focus();
      toast("Press Enter (or Send) again to send it.");
    });
  }
  function onKeydown(e) {
    if (e.key !== "Enter" || e.shiftKey || e.isComposing || !isEditable(e.target)) return;
    onSend(e, e.target);
  }
  function onClick(e) {
    const b = e.target?.closest?.("button,[role=button]");
    if (!b) return;
    const label = `${b.getAttribute("aria-label") ?? ""} ${b.getAttribute("data-testid") ?? ""} ${b.textContent ?? ""}`.toLowerCase();
    if (/\bsend\b|submit|send-button|composer-submit/.test(label)) onSend(e, lastEditable);
  }
  var uploadApproved = false;
  function describeFiles(files) {
    const exts = [...new Set([...files].map((f) => f.name.includes(".") ? f.name.split(".").pop().toLowerCase() : "file"))];
    return `${files.length} file${files.length === 1 ? "" : "s"} (${exts.slice(0, 5).join(", ")})`;
  }
  function onFiles(e, files, target, again) {
    if (!policy || !app || !files.length || policy.uploads === "allow") return;
    if (uploadApproved) {
      uploadApproved = false;
      return;
    }
    const count = files.length;
    const detail = describeFiles(files);
    const upload = (action) => ({ at: now(), kind: "upload", action, app: app.key, host, count, detail });
    stop(e);
    if (policy.uploads === "block") {
      if (target instanceof HTMLInputElement) target.value = "";
      report([upload("blocked")]);
      return toast(`Blocked: your organization doesn't allow uploading files to ${app.name}.`);
    }
    void confirmDialog(`Upload ${detail} to ${app.name}?`, `Files you upload are sent to ${app.name}.`, "Upload anyway").then((ok) => {
      report([upload(ok ? "continued" : "warned")]);
      if (!ok) {
        if (target instanceof HTMLInputElement) target.value = "";
        return;
      }
      uploadApproved = true;
      again?.();
    });
  }
  function onChange(e) {
    const input = e.target;
    if (!(input instanceof HTMLInputElement) || input.type !== "file" || !input.files?.length) return;
    onFiles(e, input.files, input, () => input.dispatchEvent(new Event("change", { bubbles: true })));
  }
  function onDrop(e) {
    const dt = e.dataTransfer;
    if (!dt?.files.length) return;
    const target = e.target;
    onFiles(e, dt.files, target, () => target.dispatchEvent(new DragEvent("drop", { bubbles: true, cancelable: true, dataTransfer: dt })));
  }
  function listen() {
    const opts = { capture: true };
    window.addEventListener("paste", onPaste, opts);
    window.addEventListener("keydown", onKeydown, opts);
    window.addEventListener("click", onClick, opts);
    window.addEventListener("change", onChange, opts);
    window.addEventListener("drop", onDrop, opts);
    window.addEventListener("focusin", (e) => isEditable(e.target) && (lastEditable = e.target), opts);
  }
  listen();
  void send({ type: "policy" }).then((r) => {
    policy = r?.policy ?? null;
    app = appFor(policy, host);
    if (app) report([{ at: now(), kind: "visit", action: "allowed", app: app.key, host }]);
  });
})();
