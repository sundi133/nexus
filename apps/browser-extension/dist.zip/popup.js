"use strict";
(() => {
  // src/popup.ts
  var $ = (id) => document.getElementById(id);
  async function render() {
    const s = await chrome.runtime.sendMessage({ type: "status" });
    $("state").textContent = !s.configured ? "Not set up" : s.lastError ? "Needs attention" : "Protecting you";
    $("state").className = !s.configured || s.lastError ? "warn" : "ok";
    $("detail").textContent = s.lastError || (s.lastSync ? `Policy up to date (${new Date(s.lastSync).toLocaleTimeString()})` : "Connecting\u2026");
    $("user").textContent = s.user || "\u2014";
    const blocked = s.policy?.apps.filter((a) => a.action === "block").map((a) => a.name) ?? [];
    $("blocked").textContent = blocked.length ? blocked.join(", ") : "none";
    $("version").textContent = chrome.runtime.getManifest().version;
  }
  $("sync").onclick = async () => {
    await chrome.runtime.sendMessage({ type: "sync" });
    await render();
  };
  void render();
})();
