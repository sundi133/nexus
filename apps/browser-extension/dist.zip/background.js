// src/policy.ts
function navigationRules(policy, extensionOrigin, allowHosts = []) {
  const rules = [];
  let id = 1;
  for (const app of policy.apps) {
    if (app.action === "allow") continue;
    const hosts = app.hosts.filter((h) => !allowHosts.includes(h));
    if (!hosts.length) continue;
    const alternation = hosts.map((h) => h.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|");
    rules.push({
      id: id++,
      priority: 1,
      action: { type: "redirect", redirect: { regexSubstitution: `${extensionOrigin}/interstitial.html?mode=${app.action}&app=${app.key}#\\0` } },
      condition: { regexFilter: `^https?://([^/]*\\.)?(${alternation})(:\\d+)?(/.*)?$`, resourceTypes: ["main_frame"] }
    });
  }
  return rules;
}

// src/background.ts
var VERSION = chrome.runtime.getManifest().version;
var MAX_QUEUE = 5e3;
var ALLOW_MINUTES = 60;
var local = () => chrome.storage.local.get(null);
var save = (v) => chrome.storage.local.set(v);
async function config() {
  const m = await chrome.storage.managed.get(["server", "token"]).catch(() => ({}));
  if (m.server && m.token) return { server: m.server.replace(/\/+$/, ""), token: m.token };
  const d = (await chrome.storage.local.get("devConfig")).devConfig;
  return d?.server && d.token ? { server: d.server.replace(/\/+$/, ""), token: d.token } : null;
}
async function profileEmail() {
  try {
    const u = await chrome.identity.getProfileUserInfo({ accountStatus: "ANY" });
    if (u?.email) return u.email;
  } catch {
  }
  return (await chrome.storage.local.get("devUser")).devUser ?? "";
}
var queueLock = Promise.resolve();
function withQueue(fn) {
  const run = queueLock.then(async () => {
    const { queue = [] } = await local();
    const out = await fn(queue);
    await save({ queue: out.queue });
    return out.result;
  });
  queueLock = run.catch(() => {
  });
  return run;
}
function report(events) {
  if (!events.length) return Promise.resolve();
  return withQueue((queue) => {
    const next = [...queue, ...events];
    return { queue: next.slice(Math.max(0, next.length - MAX_QUEUE)), result: void 0 };
  });
}
var syncing = null;
async function sync() {
  syncing ??= doSync().finally(() => syncing = null);
  return syncing;
}
async function doSync() {
  const cfg = await config();
  const st = await local();
  if (!cfg) return save({ lastError: "Not configured: install through your organization's browser policy" });
  if (st.retryAt && Date.now() < st.retryAt) return;
  const events = await withQueue((queue) => ({ queue, result: queue.slice(0, 500) }));
  const user = await profileEmail();
  try {
    const res = await fetch(`${cfg.server}/v1/browser/extension/sync`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `NexusBrowser ${cfg.token}` },
      body: JSON.stringify({ user, extension_version: VERSION, policy_version: st.policy?.version ?? "", events })
    });
    if (res.status === 503 || res.status === 429) {
      const wait = Number(res.headers.get("retry-after")) || 60;
      return save({ retryAt: Date.now() + wait * 1e3, lastError: "Nexus is busy; retrying soon" });
    }
    if (res.status === 400 || res.status === 413) {
      await withQueue((queue) => ({ queue: queue.slice(events.length), result: void 0 }));
      return save({ lastError: `Nexus refused ${events.length} events (${res.status})` });
    }
    if (!res.ok) return save({ lastError: `Nexus answered ${res.status}` });
    const body = await res.json();
    await withQueue((queue) => ({ queue: queue.slice(events.length), result: void 0 }));
    await save({ lastSync: (/* @__PURE__ */ new Date()).toISOString(), lastError: "", retryAt: 0, user });
    if (body.policy) {
      await save({ policy: body.policy });
      await applyPolicy(body.policy);
    }
  } catch (e) {
    await save({ lastError: `Can't reach Nexus: ${e.message}` });
  }
}
async function applyPolicy(policy) {
  const { allowed = {} } = await local();
  const now = Date.now();
  const allowHosts = Object.entries(allowed).filter(([, until]) => until > now).map(([h]) => h);
  const rules = navigationRules(policy, `chrome-extension://${chrome.runtime.id}`, allowHosts);
  const old = await chrome.declarativeNetRequest.getDynamicRules();
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: old.map((r) => r.id), addRules: rules });
  const matches = [...new Set(policy.apps.flatMap((a) => a.hosts.flatMap((h) => [`*://${h}/*`, `*://*.${h}/*`])))];
  await chrome.scripting.unregisterContentScripts().catch(() => {
  });
  if (matches.length) {
    await chrome.scripting.registerContentScripts([{ id: "nexus-ai", js: ["content.js"], matches, runAt: "document_start", allFrames: false, persistAcrossSessions: true }]);
  }
}
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("sync", { periodInMinutes: 1 });
  void sync();
});
chrome.runtime.onStartup.addListener(() => void sync());
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "sync") void sync();
  if (a.name === "allowances") void local().then((s) => s.policy && applyPolicy(s.policy));
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "managed" || area === "local" && "devConfig" in changes) void sync();
});
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  void (async () => {
    const st = await local();
    switch (msg?.type) {
      case "policy":
        return reply({ policy: st.policy ?? null });
      case "report":
        await report(msg.events);
        return reply({ ok: true });
      case "allow": {
        const app = st.policy?.apps.find((a) => a.key === msg.app);
        if (!app) return reply({ ok: false });
        const until = Date.now() + ALLOW_MINUTES * 6e4;
        const allowed = { ...st.allowed ?? {}, ...Object.fromEntries(app.hosts.map((h) => [h, until])) };
        await save({ allowed });
        await applyPolicy(st.policy);
        chrome.alarms.create("allowances", { when: until + 1e3 });
        return reply({ ok: true });
      }
      case "status":
        return reply({ configured: !!await config(), user: st.user ?? "", policy: st.policy ?? null, lastSync: st.lastSync ?? null, lastError: st.lastError ?? "", queued: st.queue?.length ?? 0 });
      case "sync":
        await sync();
        return reply({ ok: true });
    }
    reply(null);
  })();
  return true;
});
export {
  report
};
